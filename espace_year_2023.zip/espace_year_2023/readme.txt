ダウンロードいただきましてありがとうございます。

サイト内の利用規約を必ずご確認ください。
（利用規約: https://espace.monbalcon.net/rule/）

利用規約は予告なく変更になる場合がございます。
変更した場合はTwitterやサイトのお知らせでご報告いたします。

espaceのTwitterでは最新情報をいち早くご確認いただけますので、
よろしければフォローをお願いいたします。

また、Twitter・マシュマロ・サイト内のメールフォームより
感想、コメントなどいただけますと大変励みになります。

今後もespaceをよろしくお願いいたします。

*--------------------------------------------------*
HP > https://espace.monbalcon.net/
Twitter > https://twitter.com/espace_vvv
マシュマロ > https://marshmallow-qa.com/espace_vvv
*--------------------------------------------------*

*** 各種ファイルについて ***
[]…ディレクトリ

[temp]
    └[js]
        └general.js … 共通javascript
    └[img]
        └[layout] … デザインに使用する画像
    └[css]
        └style.css … 共通デザインCSS
    └banner.jpg … バナー画像
    └index.html … INDEXページサンプル
    └readme.txt … このファイル
    └sample.html … 汎用ページサンプル（ヘッダー有）
    └sample_no_header.html … 汎用ページサンプル（ヘッダー無）
    └top.html … TOPページサンプル（＋テンプレートについて）